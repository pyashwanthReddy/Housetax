﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HousetaxBillingSystem.Models;
using HousetaxBillingSystem.ViewModels;
using Rotativa;

namespace HousetaxBillingSystem.Controllers
{
    public class CustomerBillController : Controller
    {
        private masterEntities db = new masterEntities();

        public ActionResult Login()
        {
            return View();
        }
        public ActionResult DashBoard()
        {
            int CountforPaid = db.Bills.Where(a => a.status == "Paid" && (a.billDate.Month == DateTime.Now.Month && a.billDate.Year == DateTime.Now.Year) ).Count();
            ViewBag.CountforPaid = CountforPaid;
            int CountforNotPaid = db.Bills.Where(a => a.status == "Pending" && (a.billDate.Month == DateTime.Now.Month && a.billDate.Year == DateTime.Now.Year)).Count();
            ViewBag.CountforNotPaid = CountforNotPaid;
            return View();
        }

        [HttpPost]
        public ActionResult Login(LoginDetail adminDetail)
        {
            var isAdmin = db.LoginDetails.Where(a => a.username == adminDetail.username && a.password == adminDetail.password).SingleOrDefault();
            if (isAdmin != null)
            {
                return RedirectToAction("DashBoard");
            }
            ModelState.AddModelError("password", "Username/password incorrect");
            return View();
        }

        // GET: CustomerBill
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult customerRegister()
        {
            var res = db.CustomerDetails.Count();
            ViewBag.customerId = 1000 + res;
            return View();
        }

        [HttpPost]
        public ActionResult customerRegister(CustomerDetail customerDetail)
        {
            if (ModelState.IsValid)
            {
                db.CustomerDetails.Add(customerDetail);
                db.SaveChanges();
                var res1 = db.CustomerDetails.Count();
                ViewBag.customerId = 1000 + res1;
                return Content("<html><head><script>alert('Successfully Registered'); window.location.href = '/CustomerBill/customerRegister'</script></head></html>");
            }
            ModelState.Clear();
            var res = db.CustomerDetails.Count();
            ViewBag.customerId = 1000 + res;
            return View();
        }

        public ActionResult searchCustomerDetails()
        {
            var res = db.CustomerDetails.ToList();
            return View(res);
        }

        [HttpPost]
        public ActionResult searchCustomerDetails(int? customerId)
        {
            List<CustomerDetail> res = null;
            if (customerId != null)
            {
                res = db.CustomerDetails.Where(a => a.customerId == customerId).ToList();
                return View(res);
            }
            res = db.CustomerDetails.ToList();
            return View();
        }

        public ActionResult editCustomerDetails(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            CustomerDetail customerDetail = db.CustomerDetails.Find(id);
            if (customerDetail == null)
            {
                return HttpNotFound();
            }
            return View(customerDetail);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult editCustomerDetails([Bind(Include = "customerId,customerName,mobileNumber,houseNo,houseType,builtInArea,areaInSqfts,area,Location,pincode")] CustomerDetail customerDetail)
        {
            if (ModelState.IsValid)
            {
                db.Entry(customerDetail).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("searchCustomerDetails");
            }
            return View(customerDetail);
        }

        public ActionResult generateBill(int? id)
        {
            CustomerDetail customer = db.CustomerDetails.Find(id);
            var bill = db.Bills.Where(a => a.customerId == id).ToList();
            bool toGenerate = false;
            if (bill != null)
            {
                foreach (var item in bill)
                {
                    if (item.billDate.Month == DateTime.Now.Month && item.billDate.Year == DateTime.Now.Year)
                    {
                        toGenerate = true;
                    }
                }
            }
            if (!toGenerate)
            {
                string area = customer.area;
                string houseType = customer.houseType;
                string builtInArea = customer.builtInArea;
                int billId = db.Bills.Count();
                var price = db.Prices.Where(a => a.area == area && a.builtInArea == builtInArea && a.houseType == houseType).SingleOrDefault();
                string dueDate = DateTime.Now.Month.ToString() + "/" + "30" + "/" + DateTime.Now.Year.ToString() + " 00:00:00 AM";
                CustomerBillPrice billPrice = new CustomerBillPrice()
                {
                    customerId = customer.customerId,
                    customerName = customer.customerName,
                    Area = customer.area,
                    builtinArea = customer.builtInArea,
                    areainsqft = customer.areaInSqfts,
                    houseType = customer.houseType,
                    price = price.pricepersqft * customer.areaInSqfts,
                    BillId = billId + 10000,
                    billDate = DateTime.Now.Date,
                    billDueDate = DateTime.Parse(dueDate).Date
                };
                return View(billPrice);
            }
            return Content("<html><head><script>alert('Bill Already generated for this Month'); window.location.href = '/CustomerBill/searchCustomerDetails'</script></head></html>");
        }

        public ActionResult saveBillDetails(CustomerBillPrice customerBillPrice)
        {
            Bill bill = new Bill();
            bill.billDate = DateTime.Now.Date;
            string dueDate = DateTime.Now.Month.ToString() + "/" + "30" + "/" + DateTime.Now.Year.ToString() + " 00:00:00 AM";
            bill.billDueDate = DateTime.Parse(dueDate).Date;
            bill.billAmount = customerBillPrice.price;
            bill.customerId = customerBillPrice.customerId;
            bill.status = "Pending";
            bill.fine = 0;
            db.Bills.Add(bill);
            db.SaveChanges();
            return RedirectToAction("trackBills");
        }

        public ActionResult payBills()
        {
            var res = db.Bills.Where(a => a.status == "Pending").ToList();
            return View(res);
        }

        [HttpPost]
        public ActionResult payBills(int? billId)
        {
            List<Bill> res = null;
            if (billId != null)
            {
                res = db.Bills.Where(a => a.billId == billId && a.status == "Pending").ToList();
                return View(res);
            }
            res = db.Bills.Where(a => a.status == "Pending").ToList();
            return View();
        }

        public ActionResult amountSummary(int? id)
        {
            var res = db.Bills.Where(a => a.billId == id).ToList();
            if (DateTime.Now.Date > res[0].billDueDate)
            {
                double overduedays = (DateTime.Now.Date - res[0].billDueDate).TotalDays;
                res[0].fine = Convert.ToInt32(overduedays) * 10;
            }
            ViewBag.Total = res[0].billAmount + res[0].fine;
            return View(res);
        }

        public ActionResult updatePayStatus(int? id, int? fine)
        {
            var bill = db.Bills.Where(a => a.billId == id).SingleOrDefault();
            bill.status = "Paid";
            bill.fine = fine;
            Report newReport = new Report() { customerId = bill.customerId, billNo = bill.billId };
            db.Reports.Add(newReport);
            db.Entry(bill).State = EntityState.Modified;
            db.SaveChanges();
            return RedirectToAction("trackBills");
        }

        public ActionResult trackBills()
        {
            var res = db.Bills.ToList();
            return View(res);
        }

        public ActionResult PrintAllReport()
        {
            var report = new ActionAsPdf("reportforPaidCustomer");
            return report;
        }

        public ActionResult reportforPaidCustomer()
        {
            var res = db.Bills.Where(a => a.status == "Paid").ToList();
            var alltransactions = db.Reports.ToList();
            List<TransactionBills> trBillsList = new List<TransactionBills>();
            foreach (var item in res)
            {
                foreach (var item1 in alltransactions)
                {
                    if (item.billId == item1.billNo)
                    {
                        TransactionBills trBills = new TransactionBills();
                        trBills.CustomerId = item1.customerId;
                        trBills.CustomerName = item.CustomerDetail.customerName;
                        trBills.TransactionId = item1.transactionId;
                        trBills.Status = item.status;
                        trBills.BillId = item.billId;
                        trBills.BillAmount = item.billAmount + item.fine;
                        trBillsList.Add(trBills);
                    }
                }
            }
            return View(trBillsList);
        }

        public ActionResult Logout()
        {
            Session.Clear();
            return RedirectToAction("Login");
        }
    }
}